const projects = [// Définition de la liste des projets avec leurs détails
    {
        id: 1,
        title: "Étude d'écosystème",
        description: "Simulation en C avancé pour analyser les interactions entre espèces dans un écosystème.",
        technologies: ["C avancé"],
        date: "Novembre 2024",
        link: "https://github.com/Dida200/-tude-d-un-ecosyst-me-c-avanc-"
    },
    {
        id: 2,
        title: "Étude du système solaire",
        description: "Analyse et visualisation des trajectoires planétaires avec Python (Jupyter Notebook).",
        technologies: ["Python", "Jupyter notebook"],
        date: "Décembre 2023",
        link: "https://github.com/Dida200/Orbites"
    },
    {
        id: 3,
        title: "Proprioception dans le volley-ball",
        description: "Article scientifique sur l'impact de la proprioception dans la performance sportive.",
        technologies: ["Recherche dérigée"],
        date: "Mars 2024",
        link: "images/proprioception.pdf"
    },
    {
        id: 4,
        title: "Simulation d'automates finis",
        description: "Reproduction des fonctionnalités de JFLAP en Python pour créer et analyser des automates.",
        technologies: ["Python", "Jupyter notebook"],
        date: "Décembre 2024",
        link: "https://github.com/Dida200/automates"
    },
    {
        id: 5,
        title: "Portfolio résponsive",
        description: "créer un site web personnel interactif pour présenter mes réalisations, compétences et expériences professionnelles.",
        technologies: ["HTML", "CSS", "JavaScript", "Bootstrap"],
        date: "Décembre 2024",
        link: "portfolio.html"
    },

];
// Select modal elements
const modal = document.getElementById("modal");
const modalTitle = document.getElementById("modal-title");
const modalDescription = document.getElementById("modal-description");
const modalTechnologies = document.getElementById("modal-technologies");
const modalDate = document.getElementById("modal-date");
const modalLink = document.getElementById("modal-link");
const closeBtn = document.getElementById("close-btn");

// Ajout d'un écouteur d'événements à chaque carte de projet
document.querySelectorAll(".project-card").forEach(card => {
    card.addEventListener("click", () => {
        const projectId = card.getAttribute("data-id"); // Récupération de l'ID du projet à partir de l'attribut data-id
        const project = projects.find(p => p.id == projectId); // Recherche du projet correspondant dans la liste

        if (project) {
            modalTitle.textContent = project.title;
            modalDescription.textContent = project.description;
            // Ajout des technologies utilisées sous forme de liste
            modalTechnologies.innerHTML = "";
            project.technologies.forEach(tech => {
                const li = document.createElement("li");
                li.textContent = tech;
                modalTechnologies.appendChild(li);
            });

            modalDate.textContent = project.date;
            modalLink.href = project.link;

            modal.style.display = "flex";
        }
    });
});

// Close modal
closeBtn.addEventListener("click", () => {
    modal.style.display = "none";
});

// Close modal when clicking outside the modal content
window.addEventListener("click", (e) => {
    if (e.target === modal) {
        modal.style.display = "none";
    }
});

