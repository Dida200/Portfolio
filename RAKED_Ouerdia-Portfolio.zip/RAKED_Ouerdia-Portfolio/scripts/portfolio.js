document.querySelector('.hamburger-menu').addEventListener('click', () => { //sélectionne l'élément de class hamburger-menu 
    //et ajoute un écouter d'événement qui est que lorsque on click sur le bouton il éxécute le corps de la fonction
    document.querySelector('.menu ul').classList.toggle('active');//sélectionne le premier élément ul 
    //et ajoute la classe active à l'élément ul.
  });

// Fonction pour basculer le mode sombre
function toggleDarkMode() {
  // Toggle la classe 'dark-mode' sur le body
  document.body.classList.toggle('dark-mode');//séléctionne body et accéde au classes css de l'élément 
  //et ajoute la classe dark-mode si elle n'existe pas et la supprime si elle éxiste déja.
  
  // Sauvegarder l'état du mode sombre dans le localStorage
  if (document.body.classList.contains('dark-mode')) {
      localStorage.setItem('darkMode', 'enabled');//stocke la clé darkMode avec la valeur 'enabled' dans le stockage local du navigateur.
  } else {
      localStorage.setItem('darkMode', 'disabled');
  }
}
// Vérifier si le mode sombre est activé dans le localStorage au chargement de la page
window.onload = function () {
    if (localStorage.getItem('darkMode') === 'enabled') {
        document.body.classList.add('dark-mode');
    }
};


// Sélectionner le formulaire
const contactForm = document.getElementById('contactForm');

// Sélectionner la zone de message
const validationMessage = document.getElementById('validationMessage');

// Fonction pour valider l'email
function isValidEmail(email) {
  const emailRegex = /.+@.+\..{2,5}/;
  return emailRegex.test(email);
}

// Ajouter un gestionnaire d'événement pour la soumission du formulaire
contactForm.addEventListener('submit', function(event) {
    // Empêcher le rechargement de la page
    event.preventDefault();

    // Capturer les valeurs des champs
    const firstName = document.getElementById('firstName').value;
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const message = document.getElementById('message').value;

    // Vérification des champs vides
    if (!firstName || !name || !email || !message) {
      validationMessage.textContent = "❌ Tous les champs sont requis.";
      validationMessage.style.color = "red";
      return;
  }

  // Validation de l'email
  if (!isValidEmail(email)) {
      validationMessage.textContent = "❌ L'adresse email est invalide.";
      validationMessage.style.color = "red";
      return;
  }

  // Si tout est valide, afficher un message de succès
  validationMessage.textContent = "✅ Toutes les informations sont valides.";
  validationMessage.style.color = "green";



    // Créer un objet pour stocker les données
    const formData = {
        prenom: firstName,
        nom: name,
        email: email,
        message: message,
    };

    // Afficher les données dans une alert()
    alert(`
══════════════════════════════
      ✉️ Formulaire de Contact
══════════════════════════════
📋 **Informations saisies :**
🧑 Prénom : ${formData.prenom}
👨 Nom : ${formData.nom}
📧 Email : ${formData.email}

💬 Message :
"${formData.message}"

══════════════════════════════
Merci d'avoir rempli le formulaire !
    `);
});


